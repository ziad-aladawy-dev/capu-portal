import { useState } from "react";
import { Key, X, Eye, EyeOff, CheckCircle } from "lucide-react";
import api from "../../api/apiClient";
import "../styles/changePassword.css";

function ChangePasswordModal({ onClose }) {
  const [form, setForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmNewPassword: "",
  });
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (error) setError("");
  };

  const validate = () => {
    if (!form.currentPassword) return "Current password is required";
    if (!form.newPassword) return "New password is required";
    if (form.newPassword.length < 6) return "New password must be at least 6 characters";
    if (form.newPassword !== form.confirmNewPassword) return "Passwords do not match";
    if (form.currentPassword === form.newPassword) return "New password must be different";
    return null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const err = validate();
    if (err) { setError(err); return; }

    setSaving(true);
    setError("");
    try {
      await api.post("/auth/change-password", {
        currentPassword: form.currentPassword,
        newPassword: form.newPassword,
        confirmNewPassword: form.confirmNewPassword,
      });
      setSuccess(true);
      setTimeout(() => onClose(), 1800);
    } catch (err) {
      setError(err.response?.data?.message || err.response?.data?.Message || "Failed to change password");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="cpw-overlay" onClick={onClose}>
      <div className="cpw-modal" onClick={(e) => e.stopPropagation()}>
        <div className="cpw-header">
          <Key size={18} />
          <h2>Change Password</h2>
          <button className="cpw-close" onClick={onClose}><X size={16} /></button>
        </div>

        {success ? (
          <div className="cpw-success">
            <CheckCircle size={36} />
            <p>Password changed successfully!</p>
            <span>You may need to sign in again.</span>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="cpw-body">
              {error && <div className="cpw-error">{error}</div>}

              <div className="cpw-field">
                <label>Current Password</label>
                <div className="cpw-input-wrap">
                  <input
                    type={showCurrent ? "text" : "password"}
                    name="currentPassword"
                    value={form.currentPassword}
                    onChange={handleChange}
                    placeholder="Enter current password"
                    autoFocus
                  />
                  <button type="button" className="cpw-eye" onClick={() => setShowCurrent(!showCurrent)}>
                    {showCurrent ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
              </div>

              <div className="cpw-field">
                <label>New Password</label>
                <div className="cpw-input-wrap">
                  <input
                    type={showNew ? "text" : "password"}
                    name="newPassword"
                    value={form.newPassword}
                    onChange={handleChange}
                    placeholder="Minimum 6 characters"
                  />
                  <button type="button" className="cpw-eye" onClick={() => setShowNew(!showNew)}>
                    {showNew ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
              </div>

              <div className="cpw-field">
                <label>Confirm New Password</label>
                <input
                  type="password"
                  name="confirmNewPassword"
                  value={form.confirmNewPassword}
                  onChange={handleChange}
                  placeholder="Re-enter new password"
                />
              </div>
            </div>

            <div className="cpw-footer">
              <button type="button" className="cpw-btn cpw-btn-cancel" onClick={onClose}>Cancel</button>
              <button type="submit" className="cpw-btn cpw-btn-save" disabled={saving}>
                {saving ? "Saving…" : "Change Password"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

export default ChangePasswordModal;
